package com.example.lab4;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int progressStatus = 0;
    Handler handler;
    ProgressBar loading;
    TextView text;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loading = findViewById(R.id.progressBar);
        text = findViewById(R.id.text);
        btn  = findViewById(R.id.click);
        handler = new Handler();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn.setEnabled(false);
                showDialog();
            }
        });
    }

    private void showDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Are you sure u want to continue?");
        builder.setTitle("  Download Request");
        builder.setIcon(R.drawable.ic_twotone_cloud_download_24);
        builder.setCancelable(true);

        builder.setPositiveButton("Download", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                loading.setVisibility(View.VISIBLE);
                startDownload();
                dialogInterface.cancel();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                btn.setEnabled(true);
                Toast.makeText(MainActivity.this, "Download Cancelled", Toast.LENGTH_SHORT).show();
                dialogInterface.cancel();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void startDownload() {
        Toast.makeText(MainActivity.this, "Download Started", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (progressStatus < 100) {
                    progressStatus += 1;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            loading.setProgress(progressStatus);
                            text.setText(progressStatus+"/"+loading.getMax());
                            if(progressStatus == 100){
                                showSecondDialog();
                            }
                        }
                    });
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    private void showSecondDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Your Download is Completed!");
        builder.setTitle("  Download Status");
        builder.setIcon(R.drawable.ic_round_cloud_done_24);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        btn.setEnabled(true);
    }
}