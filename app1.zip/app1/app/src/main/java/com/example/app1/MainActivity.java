package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private Button bt;
    String in;
    EditText et;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt = findViewById(R.id.button);
        bt.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                openSecondActivity();
            }
        });
    }
    public void openSecondActivity()
    {
        et = findViewById(R.id.input);
        in = et.getText().toString();
        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra("clg",in);
        startActivity(intent);
    }
}