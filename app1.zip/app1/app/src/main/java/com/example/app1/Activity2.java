package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;


public class Activity2 extends AppCompatActivity {
    EditText et;
    Intent i;
    Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        i = getIntent();
        bundle = i.getExtras();
        String clg = (String) bundle.get("clg");
        et = findViewById(R.id.editText);
        et.setText(clg);
    }
}