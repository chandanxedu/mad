package com.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button add, delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = findViewById(R.id.add);
        delete = findViewById(R.id.delete);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delete();
            }
        });
    }

    public void add()
    {
        Toast.makeText(this, "Add", Toast.LENGTH_SHORT).show();

        FragmentManager fragM = getSupportFragmentManager();
        FragmentTransaction fragT = fragM.beginTransaction();
        fragT.replace(R.id.fragment,new Fragment1());
        fragT.addToBackStack(null);
        fragT.commit();
    }

    public void delete()
    {

        FragmentManager fragM=getSupportFragmentManager();
        FragmentTransaction fragT=fragM.beginTransaction();
        if(fragM.getBackStackEntryCount()>0) {
            fragM.popBackStack();
            Toast.makeText(this, "Deleted!", Toast.LENGTH_SHORT).show();
        }
        fragT.commit();
    }



}